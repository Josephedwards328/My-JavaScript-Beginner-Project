// I copied this part from the sorce all I did was make minor tweaks to it //
(function myFunction() {
    const quotes = [
        {
            quote:
                "Welcome to Raw Is Jericho",
            author: "Chris Jerchio"
        },
        {
            quote:"Rest In Peace",
            author:"The Undertaker"
        },
        {
            quote:"What?",
            author:"Stone Cold Steve Austin"
        },
        {
            quote:"Can You Dig It Sucka",
            author:"Booker T"
        },
        {
            quote:"The Best There Is the Best There Was and the Best There Ever Will Be",
            author:"Bret The Hitman Hart"
        },
        {
            quote:"I Am the Best in the World at What I Do",
            author:"CM Punk"
        },
        {
            quote:"Suck It",
            author:"DX"
        },
        {
            quote:"Im a Kiss Stealing, Wheeling Dealing, Limousine Riding, Jet Flyng Son of a Gun",
            author:"Ric Flair"
        },
        {
            quote:"It Doesnt Matter",
            author:"The Rock"
        },
        {
            quote:"The Champ Is Here",
            author:"John Cena"
        },
        {
            quote:"Wooooo!",
            author:"Ric Flair"
        },
        {
            quote:"Know Your Role and Shut Your Mouth",
            author:"The Rock"
        },
        {
            quote:"Cause I'm That Damn Good",
            author:"Triple H"
        },
        {
            quote:"You're Fired",
            author:"Vince McMahon"
        },
        {
            quote:"Austin 3:16 Says I Just Whooped Your Ass",
            author:"Stone Cold Steve Austin"
        },
        {
            quote:"The Heart Break Kid Has Left the Building",
            author:"Shawn Michaels"
        },

    ];


    const btn = document.getElementById("QuoteBTN");

    btn.addEventListener("click", function(){
      let random =Math.floor(Math.random() * quotes.length); 
      console.log(random);
      
      document.getElementById("quote").textContent = quotes[random].quote;
      document.querySelector(".author").textContent = quotes[random].author;
  });
})();
